#include "arduino_secrets.h"

//
#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <math.h>
#define SCREEN_WIDTH 128 // OLED display width, in pixels
#define SCREEN_HEIGHT 64 // OLED display height, in pixels
#define OLED_RESET -1 // Reset pin # (or -1 if sharing Arduino reset pin)
#define XJOY A1//the pin numbers of the x joystick and the y joystick
#define YJOY A2
#define BUTTONJOY 3//the joystick button
#define BUTTON 2//the pin number of the button
#define XTHRESHOLD 256//the x threshold to go left and right for joystick
#define YTHRESHOLD 256
//define battlecats stage
#define STAGEBORDER 8//how far from the edge the battlecats stay
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
//BITMAPS
static const unsigned char PROGMEM bitmapbase[] =
{ 
B00000000,
B00000000,
B00000000,
B00000000,
B00000000,
B00000000,
B00000000,
B00000000};
static const unsigned char PROGMEM Catbase[] =
{ 
B11111111,
B00011111,
B11111111,
B00011000,
B00100100,
B01000010,
B11111111,
B10000001,
B10000001,
B10000001,
B10000001,
B10000001,
B10000001,
B10000001,
B10000001,
B11111111};
static const unsigned char PROGMEM Enemybase[] =
{ 
B11111111,
B11111111,
B11111111,
B11111111,
B00100100,
B01000010,
B11111111,
B10000001,
B10000001,
B10000001,
B10000001,
B10000001,
B10000001,
B10000001,
B10000001,
B11111111};
static const unsigned char PROGMEM cat_passive[] =
{ 
B01111110,
B10000001,
B10100101,
B10000001,
B01111110,
B00100100,
B00100100,
B00100100};
static const unsigned char PROGMEM cat_attack[] =
{ 
B01111110,
B10000001,
B10100101,
B10000001,
B01111110,
B00000000,
B00000000,
B00000000};
static const unsigned char PROGMEM wall_cat_passive[] =
{ 
B01111110,
B10000001,
B10100101,
B10000001,
B10111101,
B10000001,
B01111110,
B00100100};
static const unsigned char PROGMEM wall_cat_attack[] =
{ 
B00000000,
B00000000,
B01111110,
B10000001,
B10111101,
B10000001,
B01111110,
B00100100};
//CLASSES
class enemy{
  public:
    //these are the cat's stats
    bool alive = 0;
    int hp = 0;
    int damage = 0;
    int damagepoint = 0;
    float xpos = 0;
    float ypos = 0;
    float speed = 0;
    //phases - how many frames the cat is passive and how many frames it attacks for
    int attackphase = 0;
    int passivephase = 0;
    int phasecounter = 0;//this counts how many frames have passed
    bool attacking = 0;//this tells if the player is attacking - takes up memory, but is helpfull for collision physics
    bool hit = 0;
    int standingdist = 0;
    const unsigned char* bitmap;
    const unsigned char* passivebitmap;//this is a pointer that gets assigned to a bitmap in init
    /*basically the way void attackphase is made up is it has a passive phase and an attack phase. In the passive phase, it just waits a certain
    number of frames, and during the attack phase, it goes through its attack animation. The passive phase always runs first, then the attack phase*/
    const unsigned char* attackbitmap;
    bool checkallcollisions();
    void phase(){
      if(phasecounter>attackphase+passivephase){//basically cycles the phase counter around. The passive phase occurs first, then the attack phase
        phasecounter=0;
      }
      if(phasecounter<=passivephase){
        bitmap = passivebitmap;
        attacking = 0;
      }
      else if(phasecounter>=passivephase){
        bitmap = attackbitmap;
        attacking = 1;
      }
      //This only moves the cat when it has space to move
      if(xpos<SCREEN_WIDTH-8-STAGEBORDER&&!checkallcollisions()){//the -8 is to account for the enemy being 8 pixils long
          xpos+= speed;
          phasecounter = 0;
      }
      else{
        phasecounter++;
      }
    }
    void frame(){
      phase();//run the phase check
      display.drawBitmap(xpos,SCREEN_HEIGHT-ypos,bitmap,8,8,WHITE);
      //kill cat
      if(hp <= 0){
        alive = 0;
      }
    }
    void init(int catindexnumber){
      if(catindexnumber == 0){
        passivebitmap = cat_passive;
        attackbitmap = cat_attack;
        hp = 20;
        damage = 2;
        damagepoint = 6;
        xpos = 0;
        ypos = 40;
        speed = 0.5;
        attackphase = 5;
        passivephase = 25;
        standingdist = 2;
      }
      else if(catindexnumber == 1){
        passivebitmap = wall_cat_passive;
        attackbitmap = wall_cat_attack;
        hp = 40;
        damage = 1;
        damagepoint = 6;
        xpos = 0;
        ypos = 40;
        speed = 0.2;
        attackphase = 5;
        passivephase = 25;
        standingdist = 2;
      }
      phasecounter = 0;//resets to the beginning of the passive phase
      alive = 1;
    }
};
class battlecat{
  public:
    //these are the cat's stats
    bool alive = 0;
    int hp = 0;
    int damage = 0;
    int damagepoint = 0;
    float xpos = 0;
    float ypos = 0;
    float speed = 0;
    //phases - how many frames the cat is passive and how many frames it attacks for
    int attackphase = 0;
    int passivephase = 0;
    int phasecounter = 0;//this counts how many frames have passed
    bool attacking = 0;//this tells if the player is attacking - takes up memory, but is helpfull for collision physics
    bool hit = 0;
    int standingdist = 0;
    const unsigned char* bitmap;
    const unsigned char* passivebitmap;//this is a pointer that gets assigned to a bitmap in init
    /*basically the way void attackphase is made up is it has a passive phase and an attack phase. In the passive phase, it just waits a certain
    number of frames, and during the attack phase, it goes through its attack animation. The passive phase always runs first, then the attack phase*/
    const unsigned char* attackbitmap;
    bool checkallcollisions();
    void phase(){
      if(phasecounter>attackphase+passivephase){//basically cycles the phase counter around. The passive phase occurs first, then the attack phase
        phasecounter=0;
      }
      if(phasecounter<=passivephase){
        bitmap = passivebitmap;
        attacking = 0;
      }
      else if(phasecounter>=passivephase){
        bitmap = attackbitmap;
        attacking = 1;
      }
      //This only moves the cat when it has space to move
      if(xpos>STAGEBORDER&&!checkallcollisions()){//the -8 is to account for the enemy being 8 pixils long
          xpos-= speed;
          phasecounter = 0;
      }
      else{
        phasecounter++;
      }
    }
    void frame(){
      phase();//run the phase check
      display.drawBitmap(xpos,SCREEN_HEIGHT-ypos,bitmap,8,8,WHITE);
      //kill cat
      if(hp <= 0){
        alive = 0;
      }
    }
    void init(int catindexnumber){
      if(catindexnumber == 0){
        passivebitmap = cat_passive;
        attackbitmap = cat_attack;
        hp = 20;
        damage = 2;
        damagepoint = -6;
        xpos = SCREEN_WIDTH-8;
        ypos = 40;
        speed = 0.5;
        attackphase = 5;
        passivephase = 25;
        standingdist = 2;
      }
      else if(catindexnumber == 1){
        passivebitmap = wall_cat_passive;
        attackbitmap = wall_cat_attack;
        hp = 40;
        damage = 1;
        damagepoint = -6;
        xpos = SCREEN_WIDTH-8;
        ypos = 40;
        speed = 0.2;
        attackphase = 5;
        passivephase = 25;
        standingdist = 2;
      }
      phasecounter = 0;//resets to the beginning of the passive phase
      alive = 1;
    }
};

//define the list of battlecats and enemies--------------------------------------
const int maxcats = 3;//the maximum cats allowed on the field at once
const int maxenemies = 3;
battlecat catlist[maxcats];
enemy enemylist[maxenemies];

bool battlecat::checkallcollisions(){
  for(enemy &currentenemy:enemylist){
    if(currentenemy.attacking&&currentenemy.damagepoint+currentenemy.xpos+8>this->xpos&&currentenemy.damagepoint+currentenemy.xpos+8<this->xpos+8&&currentenemy.alive){
      this->hp-=currentenemy.damage;
    }
    if(currentenemy.xpos<this->xpos-standingdist&&currentenemy.xpos+8>this->xpos-standingdist&&currentenemy.alive){
      return 1;
    }
  }
  return 0;//if absolutely no collisions are detected
}
bool enemy::checkallcollisions(){
  for(battlecat &currentcat:catlist){
    if(currentcat.attacking&&currentcat.damagepoint+currentcat.xpos>this->xpos&&currentcat.damagepoint+currentcat.xpos<this->xpos+8&&currentcat.alive){
      this->hp-=currentcat.damage;
    }
    if(currentcat.xpos<this->xpos+8+this->standingdist&&currentcat.xpos+8>this->xpos+8+this->standingdist&&currentcat.alive){
      return 1;
    }
  }
  return 0;//if absolutely no collisions are detected
}
//VARIABLE DEFINITIONS
const int hotbarlength = 8;
int hotbar[hotbarlength] = {0,1,2,3,4,5,6,7};
int currenthotbarslot = 0;
//button click mechanism - it makes it so the button has to be clicked and released
bool buttonclick = 0;
bool joymove = 0;//same as buttonclick but for the joystick
//UI/MONEY-----------------------------------------------------------------------------------------------------------
const int cat_cost = 10;
const int maxmoney = 100;
const float moneyperframe = 0.1f;
float money = 0;
bool moneyused = 0;//checks if you tried and failed to place a cat
//BASE HEALTH-------------------------------------------------------------------------------------------------------
int catbasehealth = 100;
int enemybasehealth = 100;
void drawuibitmap(int catindexnumber){
  if(catindexnumber == 0){
    display.drawBitmap(0,48,cat_passive,8,8,WHITE);
    display.setCursor(10,48);
    display.print("Cost: ");
    display.print(cat_cost);
    display.print(" Money: ");
    display.print(int(money));
  }
  else if(catindexnumber == 1){
    display.drawBitmap(0,48,wall_cat_passive,8,8,WHITE);
    display.setCursor(10,48);
    display.print("Cost: ");
    display.print(cat_cost);
    display.print(" Money: ");
    display.print(int(money));

  }
}
void setup() {
  // put your setup code here, to run once:
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.cp437(true);
  display.setTextColor(WHITE, BLACK);
  display.clearDisplay();
  Serial.begin(9600);
  pinMode(2,INPUT_PULLUP);
  pinMode(3,INPUT_PULLUP);
  display.invertDisplay(false);
  display.setTextWrap(false);
}
void loop() {
  //main loop
  //MONEY
  if(money<maxmoney){
    money+=moneyperframe;
  }
  //reset button and joy click
  if(digitalRead(BUTTON)){
    buttonclick = 0;
  }
  if(abs(analogRead(XJOY)-512)<XTHRESHOLD){
    joymove = 0;
  }
  if(analogRead(XJOY)-512>XTHRESHOLD&&currenthotbarslot<hotbarlength&&joymove==0){
    currenthotbarslot++;
    joymove = 1;
  }
  if(analogRead(XJOY)-512<-XTHRESHOLD&&currenthotbarslot>0&&joymove==0){
    currenthotbarslot--;
    joymove = 1;
  }
  Serial.println(currenthotbarslot);
  //use the UI, move the joystick
  if(!digitalRead(BUTTON)&&buttonclick == 0&&money>=cat_cost){
    money-=cat_cost;//subtract the cost
    buttonclick = 1;//it only registers a button press if the button has been released and then pressed
    moneyused = 0;
    for(battlecat &catpointer:catlist){
      if(catpointer.alive == 0){
        catpointer.init(hotbar[currenthotbarslot]);
        moneyused = 1;
        break;
      }
    }
    //this runs if every cat slot is taken up
    if(!moneyused){
      money+=cat_cost;
    }
  }
  for(battlecat &catpointer:catlist){
    if(catpointer.alive){
      catpointer.frame();
    }
  }
  for(enemy &enemypointer:enemylist){
    if(enemypointer.alive){
      enemypointer.frame();
    }
  }
  //summon random enemies
  if(random(0,200) == 0){
    for(enemy &enemypointer:enemylist){
      if(enemypointer.alive == 0){
        enemypointer.init(random(0,2));
        break;
      }
    }
  }
  //CAT AND ENEMY BASE HEALTH MODIFIERS
  //cat
  for(enemy &currentenemy:enemylist){
    if(currentenemy.attacking&&currentenemy.damagepoint+currentenemy.xpos+8>SCREEN_WIDTH-8&&currentenemy.damagepoint+currentenemy.xpos+8<SCREEN_WIDTH&&currentenemy.alive){
      catbasehealth-=currentenemy.damage;
    }
  }
  if(catbasehealth<=0){
    display.clearDisplay();
    display.setCursor(SCREEN_WIDTH/2-25,SCREEN_HEIGHT/2);
    display.print("GAME OVER");
    display.display();
    delay(100000);
  }
  //enemy
  for(battlecat &currentcat:catlist){
    if(currentcat.attacking&&currentcat.damagepoint+currentcat.xpos>0&&currentcat.damagepoint+currentcat.xpos<0+8&&currentcat.alive){
      enemybasehealth-=currentcat.damage;
    }
  }
  if(enemybasehealth<=0){
    display.clearDisplay();
    display.setCursor(SCREEN_WIDTH/2-25,SCREEN_HEIGHT/2);
    display.print("SUCCESS!");
    display.display();
    delay(100000);
  }
  //draw cat and enemy bases
  display.drawBitmap(SCREEN_WIDTH-8,16,Catbase,8,16,WHITE);
  display.drawBitmap(0,16,Enemybase,8,16,WHITE);
  //draw cat and enemy base healths
  //draw enemy base health
  display.setCursor(0,0);
  display.print(enemybasehealth);
  display.setCursor(SCREEN_WIDTH-18,0);
  display.print(catbasehealth);
  //draw floor
  display.drawLine(0, 32, SCREEN_WIDTH, 32, WHITE);
  //draw current cat
  drawuibitmap(hotbar[currenthotbarslot]);
  display.display();
  delay(1);
  display.clearDisplay();
}

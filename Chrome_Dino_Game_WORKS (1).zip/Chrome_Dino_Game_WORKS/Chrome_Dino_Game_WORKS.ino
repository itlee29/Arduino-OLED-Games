#include "arduino_secrets.h"

#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <math.h>

#define SCREEN_WIDTH 128 // OLED display width, in pixels
#define SCREEN_HEIGHT 64 // OLED display height, in pixels
#define XJOY A1//the pin numbers of the x joystick and the y joystick
#define YJOY A2
#define BUTTONJOY 3//the joystick button
#define BUTTON 2//the pin number of the button
// Declaration for an SSD1306 display connected to I2C (SDA, SCL pins)
#define OLED_RESET     -1 // Reset pin # (or -1 if sharing Arduino reset pin)
#define MAXHEIGHT 20
#define SCORE_SPEED_RATIO 0.0005//The ratio between the speed and the score
#define RAND_PIN A6//the pin used to seed the random number generator
#define SCOREBOOTS 200//the amount of points gained in a coinrush per coin
#define POWERDURATION 200//the time a powerup lasts
#define COINWAIT 1320//the distance the coin starts from
static const unsigned char dino[] PROGMEM = {
    B00001111,
    B00001101,
    B00001111,
    B10000100,
    B11111111,
    B11111000,
    B00101000,
    B00101000
};
static const unsigned char cactusbig[] PROGMEM = {
    B00011011,
    B00011111,
    B11011111,
    B11111000,
    B11111011,
    B00011111,
    B00011111,
    B00011000
};
static const unsigned char cactussmall[] PROGMEM = {
    B00000000,
    B00000000,
    B00000000,
    B00011000,
    B11011000,
    B11111011,
    B00011111,
    B00011000
};
static const unsigned char bird[] PROGMEM = {
    B00000000,
    B00000000,
    B00000000,
    B00000010,
    B00000110,
    B01001110,
    B11111111,
    B00111110
};
static const unsigned char coin[] PROGMEM = {
    B00111100,
    B01000010,
    B10011001,
    B10111101,
    B10111101,
    B10011001,
    B01000010,
    B00111100
};
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
int height = 0;
unsigned int score = 0;
bool hit = 0;
float speed = 1.0;
int coins = 0;
class coinclass{
  public:
    float position = 0;
    bool destroyed = 0;
    int up = 0;
    void randup(){
      this->up = random(0,2)*16;//position 0 or position 1*maxcoinheight
    }
    void render(){
      display.drawBitmap(position, 56-up, coin, 8, 8, WHITE);
    }
    void check(bool coinrush){
      if(!coinrush){
        if(up == 0){
          if(height<=1 && this->position<=22 && this->position>=8){
              coins++;
              destroyed = 1;
          }
        }
        else{
          if(height>=8 && height<=24 && this->position<=22 && this->position>=8){//change height variables in relation to maxheight
              coins++;
              destroyed = 1;
          }
        }
      }
      else{//if there is a coinrush
        if(up == 0){
          if(height<=1 && this->position<=22 && this->position>=8){
            score+=100;
            destroyed = 1;
          }
        }
        else{
          if(height>=8 && height<=24 && this->position<=22 && this->position>=8){//change height variables in relation to maxheight
            score+=100;
            destroyed = 1;
          }
        }
      }
    }
    coinclass(int pos){
      position = pos;
      this->randup();
    }
    void doduringframe(bool coinrush = 0){//coinrush is for the left powerup, where each coin hit is 100 points
      if(!destroyed){
        this->check(coinrush);
        this->render();
      }
      position-=speed;
        if(position<-16 && (random(0,500) == 0||coinrush)){//random tells if the coin will spawn again. If coinrush is on, coins play indefinately.
          position = 128;
          this->randup();
          destroyed = 0;
        }
    }
};
class enemy{
  public:
    int image = 0;//1-3 are 1-3 cacti, 4-6 are small cacti, 7 is bird low, 8 is bird middle, 9 is bird high
    float position = 0;//the position of the sprite from 128(right) to 0() 
    bool destroyed = 0;
    void setimage(){
        this->image = random(1,10);
    }
    void render(){
      switch(image){
        case 1:
          display.drawBitmap(position, 56, cactusbig, 8, 8, WHITE);
        break;
        case 2:
          display.drawBitmap(position, 56, cactusbig, 8, 8, WHITE);
          display.drawBitmap(position+8, 56, cactusbig, 8, 8, WHITE);
        break;
        case 3:
          display.drawBitmap(position, 56, cactusbig, 8, 8, WHITE);
          display.drawBitmap(position+8, 56, cactusbig, 8, 8, WHITE);
          display.drawBitmap(position+16, 56, cactusbig, 8, 8, WHITE);
        break;
        case 4:
          display.drawBitmap(position, 56, cactussmall, 8, 8, WHITE);
        break;
        case 5:
          display.drawBitmap(position, 56, cactussmall, 8, 8, WHITE);
          display.drawBitmap(position+4, 56, cactussmall, 8, 8, WHITE);
        break;
        case 6:
          display.drawBitmap(position, 56, cactussmall, 8, 8, WHITE);
          display.drawBitmap(position+4, 56, cactussmall, 8, 8, WHITE);
          display.drawBitmap(position+8, 56, cactussmall, 8, 8, WHITE);
        break;
        case 7:
          display.drawBitmap(position, 56, bird, 8, 8, WHITE);
        break;
        case 8:
          display.drawBitmap(position, 52, bird, 8, 8, WHITE);
        break;
        case 9:
          display.drawBitmap(position, 48, bird, 8, 8, WHITE);
        break;
      }
    }
    void check(){
      switch(image){
        case 1:
          if(height<=8 && this->position<=22 && this->position>=8){
            hit = 1;
          }
        break;
        case 2:
          if(height<=8 && this->position<22 && this->position>0){
            hit = 1;
          }
        break;
        case 3:
          if(height<=8 && this->position<20 && this->position>-8){
            hit = 1;
          }
        break;
        case 4:
          if(height<=4 && this->position<=24 && this->position>=16){
            hit = 1;
          }
        break;
        case 5:
          if(height<=4 && this->position<=24 && this->position>=12){
            hit = 1;
          }
        break;
        case 6:
          if(height<=4 && this->position<=24 && this->position>=8){
            hit = 1;
          }
        break;
        case 7:
          if(height<=4 && this->position<=24 && this->position>=8){
            hit = 1;
          }
        break;
        case 8:
          if(height<=8 && height>=-3 && this->position<=24 && this->position>=8){
            hit = 1;
          }
        break;
        case 9:
          if(height<=9 && height>=1 && this->position<24 && this->position>8){
            hit = 1;
          }
        break;
      }
    }
    enemy(int pos){
      position = pos;
      this->setimage();
    }
    void doduringframe(){
      if(!destroyed){
        this->check();
        this->render();
      }
      position-=speed;
        if(position<-16){
          position = 128;
          this->setimage();
          destroyed = 0;
        }
    }
};
void setup() {
  // put your setup code here, to run once:
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.cp437(true);
  display.setTextColor(WHITE, BLACK);
  display.clearDisplay();
  Serial.begin(9600);
  pinMode(2,INPUT_PULLUP);
  pinMode(3,INPUT);
  randomSeed(analogRead(RAND_PIN));
}
enemy one(128);
enemy two(216);//declaring the enemies
coinclass powerup(COINWAIT);//declaring coins, when it will enter the stage
void loop() {
  // put your main code here, to run repeatedly:
  //night and day
  score+=speed;
  if(score%2000 <= 1000){
    display.invertDisplay(true);
  }
  else{
    display.invertDisplay(false);
  }
  powerup.doduringframe();
  one.doduringframe();
  if(score<1000){
        two.doduringframe();
  }
  if(digitalRead(BUTTONJOY)){//jump and duck
    height=-4;
  }
  else if(digitalRead(BUTTON) == LOW){
    for(int i = 0;i<sqrt(MAXHEIGHT)*4;i++){
      score+=speed;
      display.clearDisplay();
      powerup.doduringframe();
      one.doduringframe();
      if(score<1000){
        two.doduringframe();
      }
      height=-pow(float(i)/2.0-float(sqrt(MAXHEIGHT)),2.0)+float(MAXHEIGHT);
      display.drawBitmap(16, 56-height, dino, 8, 8, WHITE);
      display.setCursor(88,8);
      display.print(score);
      display.setCursor(8,8);
      display.print(coins);
      display.display();
      if(hit == 1){
        display.setCursor(32,32);
        display.print("GAME OVER!!!");
        display.display();
        delay(100000);
      }
      delay(1);
    }
    height = 0;
  }
  else{
    height=0;
  }
  speed = float(float(score)*float(SCORE_SPEED_RATIO)+float(2.0));//set speed
  display.drawBitmap(16, 56-height, dino, 8, 8, WHITE);
  display.setCursor(88,8);
  display.print(score);
  display.setCursor(8,8);
  display.print(coins);
  if(coins >= 1){//POWERUPS!!!
    if(analogRead(YJOY)<256){//POWERUP UP
      coins--;
    }
    else if(analogRead(YJOY)>768){//POWERUP DOWN
      coins--;
    }
    else if(analogRead(XJOY)>768){//POWERUP LEFT COINRUSH
      coins--;
      for(int i = 0;i<POWERDURATION;i++){
          display.clearDisplay();
          powerup.doduringframe(1);
          if(digitalRead(BUTTONJOY) == LOW){//jump and duck
            height=-4;
          }
          else if(digitalRead(BUTTON) == LOW){
            for(int i = 0;i<sqrt(MAXHEIGHT)*4;i++){
              score+=speed;
              display.clearDisplay();
              powerup.doduringframe(1);
              height=-pow(float(i)/2.0-float(sqrt(MAXHEIGHT)),2.0)+float(MAXHEIGHT);
              display.drawBitmap(16, 56-height, dino, 8, 8, WHITE);
              display.setCursor(88,8);
              display.print(score);
              display.setCursor(8,8);
              display.print(coins);
              display.display();
              delay(1);
            }
            height = 0;
          }
          else{
            height=0;
          }
          if(score%2000 <= 1000){//daynight
            display.invertDisplay(true);
          }
          else{
            display.invertDisplay(false);
          }
          score+=speed;
          speed = float(float(score)*float(SCORE_SPEED_RATIO)+float(2.0));//set speed
          display.drawBitmap(16, 56-height, dino, 8, 8, WHITE);
          display.setCursor(88,8);
          display.print(score);
          display.setCursor(8,8);
          display.print(coins);
          display.display();
          delay(1);
      }
      one.position = 128;//resetting the positions of the coins and enemies
      two.position = 216;
      powerup.position = COINWAIT;
    }
    else if(analogRead(XJOY)<256){//POWERUP RIGHT
      coins--;
    }
  }
  display.display();
  if(hit == 1){
    display.setCursor(32,32);
    display.print("GAME OVER!!!");
    display.display();
    delay(100000);
  }
  delay(1);
  display.clearDisplay();
}

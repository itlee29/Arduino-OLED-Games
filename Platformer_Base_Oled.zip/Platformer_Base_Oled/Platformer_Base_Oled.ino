#include "arduino_secrets.h"

#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <math.h>
//NOTES WHEN EDITING LEVELS - Make sure to change the switch function that switches between levels as well as the number of levels there are - MAXLEVEL
#define SCREEN_WIDTH 128 // OLED display width, in pixels
#define SCREEN_HEIGHT 64 // OLED display height, in pixels
#define XJOY A1//the pin numbers of the x joystick and the y joystick
#define YJOY A2
#define BUTTONJOY 3//the joystick button
#define BUTTON 2//the pin number of the button
// Declaration for an SSD1306 display connected to I2C (SDA, SCL pins)
#define OLED_RESET -1 // Reset pin # (or -1 if sharing Arduino reset pin)
#define LEVELMAXUP 16//max height of level
#define LEVELMAXRIGHT 64//max width towards right of level
#define LEVELMAX 7//the number of levels
#define GRAVITY 1//the gravity coeficent
#define JUMP 7//how much the yvelocity increases by when jump is pressed
#define XTHRESHOLD 256//the x threshold to go left and right for joystick
#define YTHRESHOLD 256
#define XSPEED -1.5/256//the speed that the character goes left and right
#define YSPEED 1.5/256
#define ONSCREENX 64//the position on the screen of the character
#define ONSCREENY 32//from the bottom - note that with 32, the player is slightly up, which helps when falling- 24 is dead center
#define BCEXPANDX 3//the amound that the box collider should be expanded by to account for gothrough
#define BCEXPANDY 4
#define DOUBLEJUMPS 1//the number of times you can double jump
#define PLAYERSTARTX 8.0//where the player starts
#define PLAYERSTARTY 8.0
#define FALLDEATH -64//if you fall 64 blocks below the stage, you die.
#define RISE 1//you can now rise from the ground if you get embedded by falling - also looks like a spring
#define ENEMYX 2//how far the enemy moves back and forth IN BLOCKS, NOT PIXILS
#define ENEMYY 2//how high the enemy moves up and down IN BLOCKS, NOT PIXILS
#define PLATFORMX 8//how far a platform moves horizontally IN BLOCKS, NOT PIXILS
#define PLATFORMY 4//how high a platform moves vertically IN BLOCKS, NOT PIXILS
#define PLATFORMSPEED 1//how fast a platform moves
#define ENEMYSPEED 1//every frame, the enemy moves a certain distance
#define BOUNCEADD -0.1//every time a bounce collider is hit, this is added to the bounce velocity to prevent infinite bounces
#define TERMINALSUBTRACT 0.01//how much terminal velocity is decreased by from max terminal velocity
#define LAUNCHVELOCITY 10//the speed at which the launcher launches you
#define WATERBOYANCY 0.3//how much the water brings you up
#define LASERDIST 6//how far the laser travels
#define LASERSPEED 2
#define POWERJUMP 10//how high the player jumps using the jump powerup
#define POWERUPTIME 500//how long the powerup lasts
#define A 10//for hexadecimal - expands the number of platform types you can have to 16 instead of just 0-9
#define B 11
#define C 12
#define D 13
#define E 14
#define F 15
#define MAXLEVEL 7//how many levels there are - currently, there are 5 levels. - CHANGE WITH LEVELS
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
/*static const unsigned char blank[] PROGMEM = {
    B00000000,
    B00000000,
    B00000000,
    B00000000,
    B00000000,
    B00000000,
    B00000000,
    B00000000
};*/
static const unsigned char Powerup[] PROGMEM = {
    B00111100,
    B01000010,
    B10011001,
    B10100101,
    B10100101,
    B10011001,
    B01000010,
    B00111100
};
static const unsigned char blasterright[] PROGMEM = {
    B00000000,
    B01110000,
    B10011111,
    B01110000,
    B11000000,
    B10110000,
    B10001100,
    B11111111
};
static const unsigned char blasterleft[] PROGMEM = {
    B00000000,
    B00001110,
    B11111001,
    B00001110,
    B00000011,
    B00001101,
    B00110001,
    B11111111
};
static const unsigned char laser[] PROGMEM = {
    B00000000,
    B01011010,
    B10100101,
    B01011010,
    B00000000,
    B00000000,
    B00000000,
    B00000000
};
static const unsigned char water[] PROGMEM = {
    B01000100,
    B10101010,
    B00010001,
    B00000000,
    B01000100,
    B10101010,
    B00010001,
    B00000000
};
static const unsigned char launcher[] PROGMEM = {
    B00111100,
    B11111111,
    B01000010,
    B00100100,
    B00011000,
    B00100100,
    B01000010,
    B11111111
};
static const unsigned char bounce[] PROGMEM = {
    B00000000,
    B00000000,
    B00111100,
    B11111111,
    B11100111,
    B10011001,
    B11100111,
    B11111111
};
static const unsigned char jumpthrough[] PROGMEM = {
    B11111111,
    B10100101,
    B11111111,
    B00000000,
    B00000000,
    B00000000,
    B00000000,
    B00000000
};
static const unsigned char enemy[] PROGMEM = {
    B00100100,
    B01111110,
    B11111111,
    B01111110,
    B01111110,
    B11111111,
    B01111110,
    B00100100
};
static const unsigned char end[] PROGMEM = {
    B11110000,
    B11011100,
    B11000111,
    B11011100,
    B11110000,
    B11000000,
    B11000000,
    B11000000
};
static const unsigned char player[] PROGMEM = {
    B11111111,
    B10000001,
    B10111101,
    B10100101,
    B10100101,
    B10111101,
    B10000001,
    B11111111
};
static const unsigned char wall[] PROGMEM = {
    B11111111,
    B11000011,
    B10100101,
    B10011001,
    B10011001,
    B10100101,
    B11000011,
    B11111111,
};
static const unsigned char spike[] PROGMEM = {
    B00011000,
    B00011000,
    B00111100,
    B00111100,
    B01111110,
    B01111110,
    B11111111,
    B11111111
};
/*the entire level in an array going right and down. 
0 is blank, 
1 is a wall, 
2 is a spike, 
3 is a horizontal enemy, 
4 is a vertical enemy, 
5 is the end of the level, 
6 horizontal moving platform, 
7 is vertical moving platform, 
8 is jump through platform, 
9 is a bounce collider - bounces up
A is Jumper - sends you flying up
B is water - infinite jump + reduced gravity
C is blasterright
D is blasterleft
E is powerup
*/
//note that for the horizontal enemy, it starts on the left, vertical starts on bottom
//note that byte is used instead of int because byte takes up 4x less memory
//byte ranges numbers from 0 to 255 - I believe you can have around 20 or so levels
/*static const byte Blanklevel[LEVELMAXUP][LEVELMAXRIGHT] PROGMEM = {
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,}
};*/
/*EXTRA LEVELS!!!:
Basic Level - Very Easy to complete
{0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,A,1,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,1,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,0,0,0,4,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,5,},
{0,0,0,0,1,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,0,0,0,1,1,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,1,1,B,B,1,1,1,1,1,1,1,1,1,1,},
{0,A,0,0,1,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,8,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,B,B,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,1,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,B,B,1,0,0,0,0,0,0,B,B,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,7,0,0,0,0,0,0,0,0,0,0,B,B,0,0,0,0,0,0,0,B,B,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,A,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,8,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,B,B,0,0,0,0,0,0,0,B,B,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,9,9,0,0,0,0,0,0,0,0,0,0,0,B,B,B,B,B,B,B,0,0,0,0,0,0,0,B,B,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,B,B,B,B,B,B,B,0,0,0,0,0,0,B,B,B,0,0,0,0,0,0,0,0,0,0,},
{0,A,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,8,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,B,B,0,0,0,0,0,0,0,0,0,0,B,B,B,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,B,B,0,0,0,0,0,0,0,0,0,B,B,B,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,1,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,B,B,B,B,B,B,B,B,B,B,B,B,B,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{A,1,0,0,1,1,1,1,1,A,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,B,B,B,B,B,B,B,B,B,B,B,B,B,0,0,0,0,0,0,0,0,0,0,0,0,0,}

*/
static const byte level1[LEVELMAXUP][LEVELMAXRIGHT] PROGMEM = {
{1,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,1,1,1,1,0,0,0,0,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{1,2,0,0,0,2,1,1,1,2,2,1,1,0,0,1,0,0,0,2,1,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{1,0,0,0,0,0,1,0,0,0,0,1,0,0,0,1,0,0,0,0,1,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,1,0,0,0,0,0,0},
{1,0,0,0,0,0,1,0,0,0,0,1,0,0,0,1,0,0,0,0,1,0,0,1,1,2,0,0,0,0,1,1,0,0,1,1,0,0,1,1,0,0,1,1,1,1,1,0,0,2,0,0,1,1,2,2,2,1,1,1,1,0,0,0},
{1,0,0,2,0,0,1,0,0,0,0,1,0,0,1,1,0,0,0,0,1,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,2,0,0,2,0,0,0,0,0,0,0,0,0,0,0},
{1,0,0,0,0,0,1,0,0,0,0,1,0,0,0,1,2,0,0,0,1,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,2,0,0,2,0,0,0,0,0,0,0,0,0,0,0},
{1,0,0,0,0,2,1,0,0,0,0,1,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,1,2,0,0,2,0,0,0,0,0,0,0,0,1,1,0},
{1,0,5,0,0,1,1,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1,1,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0},
{1,1,1,1,1,1,0,0,0,0,0,0,1,1,1,1,1,1,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0},
{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,1,1,0,0,0},
{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,2,2,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{1,0,0,0,0,1,1,1,0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0},
{1,0,0,0,1,1,1,1,0,0,0,0,1,2,2,1,1,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0},
{1,0,0,1,1,1,1,1,0,0,0,0,1,1,1,1,1,1,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,1,0,2,0,0,0,1,1,0,0,0,1,1,0,0,0,0,0},
{1,1,1,1,1,1,1,1,2,2,2,2,1,0,0,1,1,1,1,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,1,1,2,2,1,2,1,2,1,1,1,1,2,2,2,1,1,1,1,1,1,1},
};
static const byte level2[LEVELMAXUP][LEVELMAXRIGHT] PROGMEM = {
{0,0,C,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,2,0,0,0,0,2,0,0,0,0,0,2,B,B,B,B,B,B,B,B,B,B,B,B,2,0,},
{0,1,6,1,1,1,1,1,1,1,1,1,C,0,0,2,0,0,0,2,C,0,0,0,2,0,0,0,2,0,0,0,0,0,0,0,0,2,2,2,0,0,0,2,0,0,0,0,2,B,B,B,B,B,B,2,2,B,B,B,B,B,B,2,},
{0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,A,0,0,0,0,9,9,2,0,0,0,0,0,2,0,0,0,2,B,B,B,B,B,B,2,0,0,2,B,B,B,B,B,B,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0,0,2,B,B,B,B,B,B,2,0,0,0,2,B,B,B,B,B,B,},
{A,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0,2,B,B,B,B,B,B,2,0,0,0,0,2,B,B,B,B,B,B,},
{0,0,6,0,0,0,0,0,0,1,6,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,2,2,0,2,B,B,B,B,B,B,2,0,0,0,0,2,B,B,B,B,B,B,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,D,C,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,2,2,2,0,2,B,B,B,B,B,B,2,0,0,0,0,2,B,B,B,B,B,B,},
{2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,2,2,2,2,D,C,A,A,A,A,A,A,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0,2,B,B,B,B,B,B,2,0,0,0,2,B,B,B,B,B,B,2,},
{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0,2,B,B,B,B,B,B,2,0,0,2,B,B,B,B,B,B,2,0,},
{0,0,0,0,0,2,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,2,0,0,0,2,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0,2,B,B,B,B,B,B,2,0,2,B,B,B,B,B,B,2,0,0,},
{0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,2,7,0,0,0,0,0,0,2,2,0,0,0,0,2,0,2,B,B,B,B,B,B,2,2,B,B,B,B,B,B,2,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,1,1,1,0,0,1,1,1,2,2,0,0,0,1,1,1,B,B,B,B,B,B,2,B,B,B,B,B,B,2,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,B,B,B,B,B,B,B,B,B,2,2,B,B,B,B,B,B,1,1,1,1,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,B,B,B,B,B,B,B,B,B,2,0,2,B,B,B,B,B,B,0,0,0,},
{0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,B,B,B,B,B,B,2,0,0,2,B,B,B,B,B,B,0,5,},
{1,1,1,1,0,2,0,9,0,2,0,9,0,2,0,9,0,2,0,9,0,0,0,9,0,2,0,9,0,2,0,1,1,1,A,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,2,1,1,1,1,1,1,1,}
};
static const byte level3[LEVELMAXUP][LEVELMAXRIGHT] PROGMEM = {
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,9,0,0,0,9,0,0,0,A,0,0,0,2,0,0,0,0,0,1,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,A,1,1,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,1,1,1,A,B,B,1,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,3,0,0,0,0,1,B,B,1,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,C,B,B,B,B,B,B,B,B,B,B,B,B,B,1,0,0,0,0,0,A,9,9,9,0,0,0,0,0,0,0,0,3,1,B,B,1,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,B,B,B,B,B,B,B,B,B,B,B,B,B,B,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,B,B,1,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,A,1,B,B,B,B,B,B,B,B,B,B,B,B,B,D,1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,A,0,0,0,1,B,B,1,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,B,B,B,B,B,B,B,B,B,B,B,B,B,B,1,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,0,1,B,B,1,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,C,B,B,B,B,B,B,B,B,B,B,B,B,B,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,1,B,B,1,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,B,B,B,B,B,B,B,B,B,B,B,B,B,B,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,9,9,9,0,0,A,A,A,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,4,1,1,1,4,1,1,1,A,0,0,0,0,0,1,5,0,0,1,0,},
{1,1,1,1,1,A,0,0,9,9,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,}
};
static const byte level4[LEVELMAXUP][LEVELMAXRIGHT] PROGMEM = {
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,1,1,1,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,2,0,0,0,1,0,0,4,0,0,0,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,2,0,0,0,1,0,0,A,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,A,1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,9,9,9,0,0,0,9,9,9,0,0,0,9,9,9,0,0,0,1,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,6,0,0,0,0,7,0,0,0,0,0,1,0,0,0,0,2,1,A,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,2,2,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,9,9,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,},
{0,0,0,0,6,0,0,0,0,0,1,1,1,A,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,A,1,0,0,0,9,9,9,0,0,0,0,0,0,0,A,9,9,9,0,0,0,0,0,A,1,2,1,1,1,1,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,2,0,0,0,0,0,0,0,1,0,0,0,0,0,0,9,9,9,0,0,0,0,0,0,0,0,9,9,9,0,0,0,0,0,0,0,0,5,},
{1,1,1,1,1,A,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,A,2,1,9,9,9,0,0,0,0,0,0,0,0,0,9,9,9,0,0,0,0,0,0,0,0,1,A,1,1,1,1,}
};
static const byte level5[LEVELMAXUP][LEVELMAXRIGHT] PROGMEM = {
{B,B,B,B,B,B,1,B,B,B,B,B,B,B,B,B,B,2,2,2,2,2,B,B,B,B,B,1,2,0,0,0,0,1,B,B,B,1,1,1,1,A,B,B,B,B,B,B,B,A,A,A,B,B,B,B,B,A,B,B,B,1,2,2,},
{B,B,B,B,B,B,1,B,B,B,B,B,B,B,B,B,B,B,B,1,2,B,B,B,B,B,B,1,2,2,0,0,0,1,B,B,B,1,B,B,B,B,2,2,2,2,2,2,2,B,B,B,2,2,2,2,2,1,B,B,B,1,B,B,},
{B,B,B,B,B,B,1,B,B,B,B,B,B,B,B,B,B,B,B,1,B,B,B,B,B,B,B,1,2,2,2,0,0,1,2,B,B,1,B,B,B,B,B,B,1,0,0,0,0,0,0,0,0,0,0,0,0,1,B,B,B,1,B,B,},
{B,B,B,B,B,B,1,2,2,2,2,2,2,B,B,2,2,2,2,1,B,B,B,B,B,B,B,1,0,0,0,0,0,1,B,B,B,1,B,B,B,B,B,B,1,0,0,0,0,0,0,0,0,0,0,0,0,1,B,B,B,1,B,B,},
{B,B,B,B,B,B,1,B,B,B,B,B,B,B,B,B,B,B,B,1,B,B,B,B,B,B,B,1,0,0,0,0,0,1,B,B,B,1,B,B,B,B,B,B,1,0,0,0,0,0,0,0,0,0,0,0,0,1,B,B,B,1,B,B,},
{B,B,B,B,B,B,1,B,B,B,B,B,B,B,B,B,B,B,B,1,B,B,B,B,2,2,2,1,0,0,0,0,0,1,B,B,B,1,B,B,B,B,B,B,1,0,0,0,0,0,0,0,0,0,0,0,0,1,B,B,B,1,B,B,},
{B,B,B,B,B,B,1,B,B,B,B,B,B,B,B,B,B,B,B,1,B,B,B,B,B,2,2,1,0,0,0,0,0,1,B,B,2,1,B,B,B,B,B,B,1,0,0,1,1,A,1,1,1,1,A,B,B,1,B,B,B,1,B,B,},
{B,B,B,B,B,B,1,B,B,B,B,B,B,B,B,B,B,B,B,1,B,B,B,B,B,B,2,1,0,0,0,0,0,1,B,B,B,1,B,B,B,B,B,B,1,B,B,2,2,B,5,1,B,B,1,B,B,B,B,B,B,1,B,B,},
{B,B,B,B,B,B,1,2,2,2,2,B,B,B,2,2,2,2,2,1,B,B,B,B,B,B,B,1,0,0,0,0,2,1,B,B,B,1,B,B,B,B,B,B,1,B,B,B,B,B,B,1,B,B,1,B,B,B,B,B,B,1,B,B,},
{B,B,B,B,B,B,1,B,B,B,2,B,B,B,2,B,B,B,B,1,B,B,B,B,B,B,B,1,0,0,0,2,2,1,B,B,B,1,B,B,B,B,B,B,1,B,B,B,B,B,B,1,B,B,1,1,1,1,1,1,1,1,B,B,},
{B,B,B,B,B,B,1,B,B,B,2,B,B,B,2,B,B,B,B,1,B,B,B,B,B,B,B,1,0,0,2,2,2,1,2,B,B,1,B,B,B,B,B,B,1,2,B,B,B,B,B,1,B,B,B,B,B,B,B,B,B,B,B,B,},
{B,B,B,B,B,B,1,B,B,B,2,B,B,B,B,2,B,B,B,1,1,1,1,1,1,0,0,1,0,0,1,1,1,1,B,B,B,1,B,B,B,B,B,B,1,2,2,B,B,B,2,1,B,B,B,B,B,B,B,B,B,B,B,B,},
{B,B,B,B,B,B,1,B,B,B,2,2,B,B,B,B,2,1,1,1,1,1,0,0,0,0,0,1,0,0,0,0,0,1,B,B,B,1,B,B,B,B,B,B,1,1,1,1,1,1,1,1,B,B,B,B,B,B,B,B,B,B,B,B,},
{B,B,B,B,B,B,1,B,B,B,B,2,2,B,B,B,B,B,B,B,0,0,0,0,0,0,0,1,0,0,0,0,0,0,B,B,B,1,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,},
{B,B,B,B,B,B,1,B,B,B,B,B,2,2,B,B,B,B,B,B,0,0,0,0,0,0,0,1,0,0,0,0,0,0,B,B,2,1,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,},
{1,1,1,1,1,A,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,1,1,1,1,2,2,1,1,1,1,1,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,B,}
};
static const byte level6[LEVELMAXUP][LEVELMAXRIGHT] PROGMEM = {
{2,2,2,2,2,2,2,2,2,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,2,2,0,1,0,0,0,0,0,0,0,0,0,0,0,E,0,0,0,},
{2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,1,1,1,8,},
{2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,1,1,1,1,0,0,0,A,A,A,0,0,9,9,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,0,0,0,D,0,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{2,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,8,},
{C,0,0,0,0,1,0,0,0,0,0,4,0,0,4,0,0,0,0,0,1,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{2,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,5,1,3,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{2,0,0,0,0,1,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,A,A,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,8,},
{C,0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{2,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{2,0,0,0,0,0,0,7,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,8,},
{2,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,A,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,A,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,},
{0,0,0,0,0,0,0,0,0,0,0,0,3,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{1,1,1,1,1,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,0,0,0,9,0,0,0,9,0,0,0,A,0,0,0,0,0,0,0,0,0,0,A,0,0,0,0,A,0,0,0,0,0,0,0,}
};
static const byte level7[LEVELMAXUP][LEVELMAXRIGHT] PROGMEM = {
{0,0,0,0,0,0,0,0,0,0,0,0,2,2,2,2,0,0,0,0,0,0,0,2,2,2,0,0,0,0,0,0,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,2,2,2,2,2,0,E,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,1,1,0,0,0,2,2,1,1,0,0,0,0,1,A,2,1,1,1,2,2,1,1,0,0,0,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,2,2,2,2,2,2,A,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,C,2,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,B,B,2,2,2,0,0,0,0,0,2,0,0,0,A,2,2,2,2,2,1,0,0,0,2,5,0,2,2,2,2,2,2,2,2,2,A,0,0,0,},
{0,0,0,0,2,A,0,0,2,1,0,0,2,0,0,0,0,0,0,0,2,0,0,0,B,B,B,2,2,2,0,0,0,0,2,0,0,0,0,2,2,2,0,0,0,0,0,0,2,D,1,0,0,0,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,2,0,0,0,2,0,0,0,1,1,0,0,2,0,0,0,B,B,B,2,2,2,0,0,0,0,2,0,0,0,0,0,2,2,0,0,0,0,0,0,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,2,0,0,0,2,1,0,0,0,0,D,A,0,0,0,1,B,B,B,2,2,2,0,0,0,0,2,A,0,0,0,0,0,2,0,0,0,0,9,9,2,0,0,0,0,0,0,0,2,0,0,0,0,0,2,A,},
{0,0,0,0,0,0,0,0,2,0,0,0,2,0,0,0,0,0,0,0,0,0,0,2,2,B,B,2,2,0,0,0,0,2,2,2,0,0,0,0,0,2,2,0,0,0,0,0,2,0,0,0,0,4,0,0,2,0,0,A,0,0,1,0,},
{0,0,0,A,2,0,0,0,2,0,0,0,2,0,0,0,0,0,0,0,0,0,0,2,B,B,B,2,0,0,0,0,2,2,2,2,2,0,0,0,0,2,2,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,C,2,0,0,0,2,1,1,2,2,1,1,1,1,1,0,2,B,B,B,2,0,0,0,0,2,2,2,2,1,A,0,0,0,2,2,0,0,0,0,0,2,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,0,2,0,0,1,2,2,2,2,2,2,2,2,2,2,2,2,B,B,B,2,0,0,0,2,2,2,2,2,0,0,0,0,0,2,2,2,1,1,0,0,D,0,0,0,0,0,0,0,2,A,0,0,0,A,0,0,},
{0,0,0,0,0,0,0,0,2,0,0,0,2,0,0,0,0,0,0,0,0,0,0,2,B,B,2,2,0,0,0,1,1,1,1,0,0,0,0,0,0,2,0,0,0,0,0,0,2,0,0,0,0,4,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,2,A,0,0,2,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,B,B,B,2,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,2,0,0,0,0,2,0,0,0,0,0,0,0,0,0,3,},
{0,0,0,0,0,0,0,0,2,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,B,B,B,2,2,0,0,0,0,0,0,0,0,0,A,A,A,2,2,0,0,0,0,2,2,0,0,A,0,2,0,0,0,0,0,0,0,0,0,A,},
{0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,B,B,B,2,2,0,0,0,0,0,0,0,0,0,2,2,2,2,2,0,0,0,0,0,0,0,3,0,0,2,0,0,0,0,0,0,0,0,0,0,},
{0,0,0,0,0,0,0,C,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,B,B,B,2,2,2,0,0,0,0,1,1,A,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,2,0,0,2,0,3,0,0,0,0,0,},
{1,1,0,A,2,0,0,0,2,0,0,1,1,1,1,A,1,1,A,1,1,A,1,1,2,B,B,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,1,1,1,1,1,1,A,0,0,2,9,9,2,9,9,9,9,9,9,9,}
};
//player controls and variables
float playerx = PLAYERSTARTX;//player position to start
float playery = PLAYERSTARTY;
float yvelocity = 0;//y velocity that the player is going at
int jumpsleft = 0;//how many double jumps a player has left
bool up = 1;//can the player move in certian directions
bool down = 1;
bool right = 1;
bool left = 1;
bool shorterdown = 1;//same as down but for a smaller box collider - is used so player can rise out of the ground if gravity function detects that the player is in the ground - that is not affected if the player hits the side of a wall
//the level you are playing
int level = 1;
//the type of thing on each level - 0 is air, 1 is block...
int levelpart = 0;
//the collision of objects - sets the player's moveable options
float enemyx = 0;//as the enemies move side to side
float enemyy = 0;//as the enemy moves up and down
float platformx = 0;//same for platforms
float platformy = 0;
bool enemyxflip = 0;//when to turn around the enemies and platforms so they move back and forth
bool enemyyflip = 0;
bool platformxflip = 0;
bool platformyflip = 0;
float laserpos = 0;//the position where the laser is from the launcher - cordinated for right lasers, left lasers do the opposite
float poweruptimer = 0;
void collision(int x,int y,int platform = 1){
  //the platform - if it is 6, it adds horizontal movement to the player. 7 adds vertical movement
  //uses x*8 and y*8 cordinates - not y inversed
  if(playerx<x+8+BCEXPANDX && playerx+8+BCEXPANDX>x && playery-8-BCEXPANDY<y && playery>y-8-BCEXPANDY){
    //if the player has collided, with what?
    //2nd if statement needed so player can slip sideways - checks if the player's hitbox is within the actual hitbox(not expanded) of the terrain
    //this is needed because the box colliders were expanded to prevent falling through, so to prevent the player from not being able to move sideways, when checking the left and right moving abilities, it only checks if the player is deeply embedded in the wall, not its expand hitbox. The player will stop falling if it is in the expanded hitbox, but it will not catch on the next hitboxes when moving sideways because those are shorter than the falling expanded hitbox.
    if(playery-8<y && playery>y-8){
      if(playerx<x+8+BCEXPANDX && playerx>x+4){//player is to right of wall
        left = 0;
      }
      if(playerx+8+BCEXPANDX>x && playerx+4<x){//player is to left of wall
        right = 0;
      }
    }
    if(playerx-8<x && playerx>x-8){
      //2nd if statement needed so player can slip sideways - same as above
      if(playery-8-BCEXPANDY<y && playery-4>y){//player is above wall
        down = 0;
        //this is used so if the player lands on a platform, if it is 6, or horizontal, the player moves sideways with the platform, and if it is 7, or vertical, the player moves vertically with the platform. - 7 is not really needed, but it smooths out the movement
        switch(platform){
          case 6:
            if(!platformxflip){
              playerx+=PLATFORMSPEED;
            }
            else{
              playerx-=PLATFORMSPEED;
            }
          break;
          case 7:
            if(!platformyflip){
              playery+=PLATFORMSPEED;
            }
            else{
              playery-=PLATFORMSPEED;
            }
            break;
          case 9:
            //for bounce colliders - negates player velocity and makes them bounce upwards
            yvelocity = abs(yvelocity)+BOUNCEADD;
            jumpsleft = DOUBLEJUMPS;//because the velocity is immediately set positive, I needed to add this to reset the jumps if you hit a bounce collider, otherwise, bounce colliders will not let you jump
          break;
          case 10:
            //for jump colliders - makes them jump upwards
            yvelocity = LAUNCHVELOCITY;
            jumpsleft = DOUBLEJUMPS;//because the velocity is immediately set positive, I needed to add this to reset the jumps if you hit a jump collider, otherwise, bounce colliders will not let you jump
          break;
        }
      }
      if(playery>y-8-BCEXPANDY && playery<y-4){//player is under wall
        up = 0;
      }
      if(playery-8<y && playery-4>y){//same as player is above wall, but for a lower, unexpanded box collider - for the rising out of the ground function
        shorterdown = 0;
      }
    }
  }
}
bool jumpthroughcollision(int x,int y){
  //this type of collision only detects landing - nothing else happens if there is no collision other than landing. It is used for jump through platforms that you can jump through and land on
  if(playerx-8<x && playerx>x-8){
    //2nd if statement needed so player can slip sideways - same as above
    if(playery-8-BCEXPANDY<y && playery-4>y){//player is above wall
      down = 0;
    }
  }
}
//simply checks if the player collided - used for enemies and spikes
bool collided(int x,int y){//uses x*8 and y*8 cordinates - not y inversed - BCEXPAND is not needed because this is only for enemies and spikes, which player can pass through and die
  if(playerx<x+8 && playerx+8>x && playery-8<y && playery>y-8){
    return 1;
  }
  else{
    return 0;
  }
}
int rendery(int yvalue){
  //the OLED y position when trying to animate on the OLED - note it is reversed
  return 56-yvalue;
}
//gameover function
void GAMEOVER(){
  //called whenever you hit an enemy or spike or fall, ends the game perminately
  display.clearDisplay();
  display.setCursor(32,32);
  display.print("GAME OVER!!!");
  display.display();
  delay(2000);//wait 2 seconds and then reset the game
  HOMEPAGE();
}
void LEVELRESET(){
  yvelocity = 1;
  playerx = PLAYERSTARTX;
  playery = PLAYERSTARTY;
  enemyx = 0;
  enemyy = 0;
  platformx = 0;
  platformy = 0;
  enemyxflip = 0;
  enemyyflip = 0;
  platformxflip = 0;
  platformyflip = 0;
  laserpos = 0;
  poweruptimer = 0;
}
void NEXTLEVEL(){
  //called when you reach the end flag - sets up the next level - sends you to the homepage and makes the level go up
  display.clearDisplay();
  display.setCursor(4,32);
  display.print("LEVEL ");
  display.print(level);
  display.print(" COMPLETED!!!");
  display.display();
  delay(2000);//wait 2 seconds and then enter the homepage
  if(level<LEVELMAX){//make sure levels cannot go past LEVELMAX
    level++;
  }
  HOMEPAGE();
}
void HOMEPAGE(){
  //the navigation homepage - called by GAMEOVER function
  //joystick up and down to navigate up and down, button to select.
  /*NOTES - To do this, use setcursor and print, use MAXLEVEL to set the max scrolling, print the current level, the level before it above it, 
  and the next level under it. Change the variable level as you do this, and use a while loop until */
  while(digitalRead(BUTTON)!=0){
    //clears the display
    display.clearDisplay();
    //while the button is not pressed
    //add computational logic here
    if(-(analogRead(YJOY)-512)<=YTHRESHOLD&&level<MAXLEVEL){
      //joystick up - cannot go over MAXLEVEL
      level++;
    }
    if(-(analogRead(YJOY)-512)>=-YTHRESHOLD&&level>1){
      //joystick down - cannot go under 1
      level--;
    }
    //add printing commands - print out the screen
    //prints out the current level
    display.setCursor(32,32);
    display.print("Level: ");
    display.print(level);
    //prints out previous level
    if(level>=1+1){
      //level>1+1 because if level is one, there is no previous level - prints below current level
      display.setCursor(72,48);
      display.print(level-1);
    }
    //prints out next level
    if(level<=MAXLEVEL-1){
      //level>1+1 because if level is one, there is no previous level - prints below current level
      display.setCursor(72,16);
      display.print(level+1);
    }
    //prints out words "Homepage!"
    display.setCursor(0,8);
    display.print("Homepage!");
    //displays
    display.display();
    delay(200);
  }
  LEVELRESET();
}
void setup() {
  // put your setup code here, to run once:
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.cp437(true);
  display.setTextColor(WHITE, BLACK);
  display.clearDisplay();
  Serial.begin(9600);
  pinMode(2,INPUT_PULLUP);
  pinMode(3,INPUT_PULLUP);
  display.invertDisplay(false);
  display.setTextWrap(false);
  //makes sure that the game does not wrap 
  //the game starts you on the homepage
  HOMEPAGE();
}
void loop() {
  //this following code is not optomized
  for(int posy = 0;posy<LEVELMAXUP;posy++){
    for(int posx = 0;posx<LEVELMAXRIGHT;posx++){
      //note - levelmaxup-posy is caused because the for loop is inverted for posy. Also, for some reason, the level ordinates are y,x
      //looks through the levels
      //add levels if needed
      switch(level){
        case 1:
          levelpart = pgm_read_byte_near(&level1[LEVELMAXUP-posy-1][posx]);
        break;
        case 2:
          levelpart = pgm_read_byte_near(&level2[LEVELMAXUP-posy-1][posx]);
        break;
        case 3:
          levelpart = pgm_read_byte_near(&level3[LEVELMAXUP-posy-1][posx]);
        break;
        case 4:
          levelpart = pgm_read_byte_near(&level4[LEVELMAXUP-posy-1][posx]);
        break;
        case 5:
          levelpart = pgm_read_byte_near(&level5[LEVELMAXUP-posy-1][posx]);
        break;
        case 6:
          levelpart = pgm_read_byte_near(&level6[LEVELMAXUP-posy-1][posx]);
        break;
        case 7:
          levelpart = pgm_read_byte_near(&level7[LEVELMAXUP-posy-1][posx]);
        break;
      }
      switch(levelpart){
        //note that you have to do pgm_read_byte_near(&level[LEVELMAXUP-posy-1][posx]) to read progmem data - note the -8 at the end - I had to include it because the occlusion culling at 0 cut the rendering short
        case 1://wall
          //draws bitmap if in screen - allows for occlusion culling
          if(posx*8-playerx+ONSCREENX<=SCREEN_WIDTH && posx*8-playerx+ONSCREENX>=-8 && rendery(posy*8-playery+ONSCREENY)<=SCREEN_HEIGHT && rendery(posy*8-playery+ONSCREENY)>=-8){
            display.drawBitmap(posx*8-playerx+ONSCREENX,rendery(posy*8-playery+ONSCREENY),wall,8,8,WHITE);
          }
          collision(posx*8,posy*8);
        break;
        case 2://spike
          if(posx*8-playerx+ONSCREENX<=SCREEN_WIDTH && posx*8-playerx+ONSCREENX>=-8 && rendery(posy*8-playery+ONSCREENY)<=SCREEN_HEIGHT && rendery(posy*8-playery+ONSCREENY)>=-8){
            display.drawBitmap(posx*8+ONSCREENX-playerx,rendery(posy*8-playery+ONSCREENY),spike,8,8,WHITE);
          }
          if(collided(posx*8,posy*8)){
            GAMEOVER();
          }
        break;
        case 3://horizontal enemy
          if(posx*8-playerx+ONSCREENX+enemyx<=SCREEN_WIDTH && posx*8-playerx+ONSCREENX+enemyx>=-8 && rendery(posy*8-playery+ONSCREENY)<=SCREEN_HEIGHT && rendery(posy*8-playery+ONSCREENY)>=-8){
            display.drawBitmap(posx*8+ONSCREENX-playerx+enemyx,rendery(posy*8-playery+ONSCREENY),enemy,8,8,WHITE);
          }
          if(collided(posx*8+enemyx,posy*8)){
            GAMEOVER();
          }
        break;
        case 4://vertical enemy
          if(posx*8-playerx+ONSCREENX<=SCREEN_WIDTH && posx*8-playerx+ONSCREENX>=-8 && rendery(posy*8-playery+ONSCREENY+enemyy)<=SCREEN_HEIGHT && rendery(posy*8-playery+ONSCREENY+enemyy)>=-8){
            display.drawBitmap(posx*8+ONSCREENX-playerx,rendery(posy*8-playery+ONSCREENY+enemyy),enemy,8,8,WHITE);
          }
          if(collided(posx*8,posy*8+enemyy)){
            GAMEOVER();
          }
        break;
        case 5://end
          if(posx*8-playerx+ONSCREENX<=SCREEN_WIDTH && posx*8-playerx+ONSCREENX>=-8 && rendery(posy*8-playery+ONSCREENY)<=SCREEN_HEIGHT && rendery(posy*8-playery+ONSCREENY)>=-8){
            display.drawBitmap(posx*8+ONSCREENX-playerx,rendery(posy*8-playery+ONSCREENY),end,8,8,WHITE);
          }
          if(collided(posx*8,posy*8)){
            NEXTLEVEL();
          }
        break;
        case 6://horizontal platform
          //draws bitmap if in screen - allows for occlusion culling
          if(posx*8-playerx+ONSCREENX+platformx<=SCREEN_WIDTH && posx*8-playerx+ONSCREENX+platformx>=-8 && rendery(posy*8-playery+ONSCREENY)<=SCREEN_HEIGHT && rendery(posy*8-playery+ONSCREENY)>=-8){
            display.drawBitmap(posx*8-playerx+ONSCREENX+platformx,rendery(posy*8-playery+ONSCREENY),jumpthrough,8,8,WHITE);
          }
          collision(posx*8+platformx,posy*8,6);
        break;
        case 7://vertical platform
          //draws bitmap if in screen - allows for occlusion culling
          if(posx*8-playerx+ONSCREENX<=SCREEN_WIDTH && posx*8-playerx+ONSCREENX>=-8 && rendery(posy*8-playery+ONSCREENY+platformy)<=SCREEN_HEIGHT && rendery(posy*8-playery+ONSCREENY+platformy)>=-8){
            display.drawBitmap(posx*8-playerx+ONSCREENX,rendery(posy*8-playery+ONSCREENY+platformy),jumpthrough,8,8,WHITE);
          }
          collision(posx*8,posy*8+platformy,7);
        break;
        case 8://jumpthrough platform
          if(posx*8-playerx+ONSCREENX<=SCREEN_WIDTH && posx*8-playerx+ONSCREENX>=-8 && rendery(posy*8-playery+ONSCREENY)<=SCREEN_HEIGHT && rendery(posy*8-playery+ONSCREENY)>=-8){
            display.drawBitmap(posx*8-playerx+ONSCREENX,rendery(posy*8-playery+ONSCREENY),jumpthrough,8,8,WHITE);
          }
          //note for collision - this platform only affects landing on it, nothing else. - therefore, it uses a special type of collision
          jumpthroughcollision(posx*8,posy*8);
        break;
        case 9://bounce platform
          //draws bitmap if in screen - allows for occlusion culling
          if(posx*8-playerx+ONSCREENX<=SCREEN_WIDTH && posx*8-playerx+ONSCREENX>=-8 && rendery(posy*8-playery+ONSCREENY)<=SCREEN_HEIGHT && rendery(posy*8-playery+ONSCREENY)>=-8){
            display.drawBitmap(posx*8-playerx+ONSCREENX,rendery(posy*8-playery+ONSCREENY),bounce,8,8,WHITE);
          }
          collision(posx*8,posy*8,9);
        break;
        case A://jump platform
          //draws bitmap if in screen - allows for occlusion culling
          if(posx*8-playerx+ONSCREENX<=SCREEN_WIDTH && posx*8-playerx+ONSCREENX>=-8 && rendery(posy*8-playery+ONSCREENY)<=SCREEN_HEIGHT && rendery(posy*8-playery+ONSCREENY)>=-8){
            display.drawBitmap(posx*8-playerx+ONSCREENX,rendery(posy*8-playery+ONSCREENY),launcher,8,8,WHITE);
          }
          collision(posx*8,posy*8,A);
        break;
        case B://water
          //draws bitmap if in screen - allows for occlusion culling
          if(posx*8-playerx+ONSCREENX<=SCREEN_WIDTH && posx*8-playerx+ONSCREENX>=-8 && rendery(posy*8-playery+ONSCREENY)<=SCREEN_HEIGHT && rendery(posy*8-playery+ONSCREENY)>=-8){
            display.drawBitmap(posx*8-playerx+ONSCREENX,rendery(posy*8-playery+ONSCREENY),water,8,8,WHITE);
          }
          if(collided(posx*8,posy*8)){
            yvelocity+=WATERBOYANCY;
            jumpsleft = DOUBLEJUMPS;//for infinite jumps in water
          }
        break;
        case C://laser right
          //draws laser blaster
          //draws bitmap if in screen - allows for occlusion culling
          if(posx*8-playerx+ONSCREENX<=SCREEN_WIDTH && posx*8-playerx+ONSCREENX>=-8 && rendery(posy*8-playery+ONSCREENY)<=SCREEN_HEIGHT && rendery(posy*8-playery+ONSCREENY)>=-8){
            display.drawBitmap(posx*8-playerx+ONSCREENX,rendery(posy*8-playery+ONSCREENY),blasterright,8,8,WHITE);
          }
          collision(posx*8,posy*8);
          //draw laser
          if(posx*8-playerx+ONSCREENX+laserpos<=SCREEN_WIDTH && posx*8-playerx+ONSCREENX+laserpos>=-8 && rendery(posy*8-playery+ONSCREENY)<=SCREEN_HEIGHT && rendery(posy*8-playery+ONSCREENY)>=-8){
            display.drawBitmap(posx*8+ONSCREENX-playerx+laserpos,rendery(posy*8-playery+ONSCREENY),laser,8,8,WHITE);
          }
          if(collided(posx*8+laserpos,posy*8)){
            GAMEOVER();
          }
        break;
        case D://laser left
          //draws laser blaster
          //draws bitmap if in screen - allows for occlusion culling
          if(posx*8-playerx+ONSCREENX<=SCREEN_WIDTH && posx*8-playerx+ONSCREENX>=-8 && rendery(posy*8-playery+ONSCREENY)<=SCREEN_HEIGHT && rendery(posy*8-playery+ONSCREENY)>=-8){
            display.drawBitmap(posx*8-playerx+ONSCREENX,rendery(posy*8-playery+ONSCREENY),blasterleft,8,8,WHITE);
          }
          collision(posx*8,posy*8);
          //draw laser
          if(posx*8-playerx+ONSCREENX-laserpos<=SCREEN_WIDTH && posx*8-playerx+ONSCREENX-laserpos>=-8 && rendery(posy*8-playery+ONSCREENY)<=SCREEN_HEIGHT && rendery(posy*8-playery+ONSCREENY)>=-8){
            display.drawBitmap(posx*8+ONSCREENX-playerx-laserpos,rendery(posy*8-playery+ONSCREENY),laser,8,8,WHITE);
          }
          if(collided(posx*8-laserpos,posy*8)){
            GAMEOVER();
          }
        break;
        case E://powerup
          //draw powerup
          if(posx*8-playerx+ONSCREENX<=SCREEN_WIDTH && posx*8-playerx+ONSCREENX>=-8 && rendery(posy*8-playery+ONSCREENY)<=SCREEN_HEIGHT && rendery(posy*8-playery+ONSCREENY)>=-8){
            display.drawBitmap(posx*8+ONSCREENX-playerx,rendery(posy*8-playery+ONSCREENY),Powerup,8,8,WHITE);
          }
          if(collided(posx*8,posy*8)){
            poweruptimer = POWERUPTIME;//sets the time that the powerup works for
          }
        break;
      }
    }
  }
  //Move and flip the laser
  laserpos+=LASERSPEED;
  if(laserpos>=LASERDIST*8){
    //note the *8 because laserspeed is in pixils
    laserpos = 0;
  }
  //Move the enemies
  if(!enemyxflip){
    enemyx+=ENEMYSPEED;
  }
  else{
    enemyx-=ENEMYSPEED;
  }
  //flip the enemy - make it move left and right
  if(enemyx>=ENEMYX*8||enemyx<=0){
    enemyxflip = !enemyxflip;
  }
  //move the vertical enemy
  if(!enemyyflip){
    enemyy+=ENEMYSPEED;
  }
  else{
    enemyy-=ENEMYSPEED;
  }
  //flip the enemy - make it move up and down
  if(enemyy>=ENEMYY*8||enemyy<=0){
    enemyyflip = !enemyyflip;
  }
  //move the horizontal platform
  if(!platformxflip){
    platformx+=PLATFORMSPEED;
  }
  else{
    platformx-=PLATFORMSPEED;
  }
  //flip the platform - make it move up and down
  if(platformx>=PLATFORMX*8||platformx<=0){
    platformxflip = !platformxflip;
  }
  //move the vertical platform
  if(!platformyflip){
    platformy+=PLATFORMSPEED;
  }
  else{
    platformy-=PLATFORMSPEED;
  }
  //flip the platform - make it move up and down
  if(platformy>=PLATFORMY*8||platformy<=0){
    platformyflip = !platformyflip;
  }
  //power ups
  if(poweruptimer>0){
    //decreases the power up timer
    poweruptimer--;
    //prints the powerup time
    display.setCursor(64,8);
    display.print("Power:");
    display.print(int(poweruptimer));
  }
  //note yjoy is flipped
  //GRAVITY AND JUMP
  //Gravity
  yvelocity-=GRAVITY;
  if(!down && yvelocity<=0){
    //if it is touching the ground and not jumping
    yvelocity = 0;
    jumpsleft = DOUBLEJUMPS;
    if(!shorterdown){
      //allows the player to rise out of the ground if it gets embedded - ENABLE OR DISABLE IF NEEDED - WORKS PERFECTLY
      playery+=RISE;
    }
  }
  else{
    if(up||yvelocity<0){
        /*terminal velocity - if the yvelocity exceeds a point(4(the inner box collider area)+BCEXPAND(essentially combined, 
        the entire box collider area)), then the player will continue to move at that velocity - the exact point where the velocity exceeded. 
        This is because if the player moves faster than that, it can fall through the floor as the box collider does not trigger.
        Note that this does not change the velocity, the velocity can exceed that, but it changes how fast the player moves for each velocity tick that is higher than the terminal velocity.
        this allows for infinite height jumping, but also prevents the player from falling through the floor*/
      if(yvelocity>=4+BCEXPANDY){
        //terminal velocity up - terminalsubtract makes sure that this statement does not run every single time, redunding itself
        playery += 4+BCEXPANDY-TERMINALSUBTRACT;
      }
      else if(yvelocity<=-(4+BCEXPANDY)){
        //terminal velocity down - terminalsubtract makes sure that this statement does not run every single time, redunding itself
        playery -= 4+BCEXPANDY-TERMINALSUBTRACT;
      }
      else{
        playery+=yvelocity;
      }
    }
    else{
      //if the player hits the ceiling, all velocity is immediately stopped, and the player goes downwards
      yvelocity = 0;
    }
  }
  //jump
  if(digitalRead(BUTTON)==LOW && jumpsleft>0){
    //if the powerup is activated, you get higher jump
    if(poweruptimer>0){
      yvelocity = POWERJUMP;
    }
    else{
      yvelocity = JUMP;
    }
    playery+=BCEXPANDY;//to escape the box collider
    jumpsleft--;
  }
  if(analogRead(XJOY)-512>=XTHRESHOLD&&left){//left
    playerx+=(analogRead(XJOY)-512)*XSPEED;
  }
  if(analogRead(XJOY)-512<=-XTHRESHOLD&&right){
    playerx+=(analogRead(XJOY)-512)*XSPEED;
  }
  display.drawBitmap(ONSCREENX,rendery(ONSCREENY),player,8,8,WHITE);
  //undo movements into walls - sets playerx,y  it to a multiple of 8, round in one direction or another
  up = 1;//reset box collider stops
  down = 1;
  left = 1;
  right = 1;
  shorterdown = 1;
  //FALLDEATH - checks if you fall past the stage
  if(playery<=FALLDEATH){
    GAMEOVER();
  }
  // put your main code here, to run repeatedly:
  //display.drawBitmap(x,y,bitmap,bx,by,WHITE);
  //display.invertDisplay(true);
  //display.setCursor(x,y);
  //display.print(text);
  //display.write(character);
  display.display();
  delay(1);
  display.clearDisplay();
}

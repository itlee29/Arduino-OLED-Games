#include "arduino_secrets.h"

#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <math.h>
#define SCREEN_WIDTH 128 // OLED display width, in pixels
#define SCREEN_HEIGHT 64 // OLED display height, in pixels
#define OLED_RESET -1 // Reset pin # (or -1 if sharing Arduino reset pin)
#define XJOY A1//the pin numbers of the x joystick and the y joystick
#define YJOY A2
#define BUTTONJOY 3//the joystick button
#define BUTTON 2//the pin number of the button
#define XTHRESHOLD 256//the x threshold to go left and right for joystick
#define YTHRESHOLD 256
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
float playery = 64;
/*IMPORTANT NOTE: the top left corner of the OLED is (0,0), however in all drawBitmap commands, 
I include SCREEN_HEIGHT-playery. This is so the y axis is normalized - 
basically it makes the bottom left corner (0,0), which makes physics actually make sense!
I'm ignoring everyone who claims that south is up, and I'm acknowleging the innate computing bias.*/
float playerx = 64;
float playervelocityx = 0;
float playervelocityy = 0;
const float playeraccelerationx = 0.2;
const float playeraccelerationgravity = -0.1;
const float playerengineacceleration = 0.2;
//drag (I know there's little to no drag on the moon, but like I dont want the player to accelerate indefinately)
float dragaccelforce = 0;
const float dragscalar = 0.025;
//the way drag is calculated is by using the actual drag formula in real life!
//I'm using dragscalar as the rest of the drag formula, and using playervelocity^2 as the other part
//fuel
float fuel = 128;//current fuel
const float maxfuel = 128;//maximum fuel
const float fuelbarwidth = 4;//the width of the fuel bar - 4 pixils
//target
const float fuelbarmaxheight = 64;//the max height of the fuel bar
float targetx = 0;
float targety = 6;//5 + 1, because the entire lower row of pixils is the ground
const float maxlandingvelocityx = 1;
const float maxlandingvelocityy = 1;
//BITMAPS
static const unsigned char PROGMEM LanderIdle[] =
{ 
B11111111,
B10011001,
B10011001,
B11111111,
B00100100,
B01000010,
B10000001,
B10000001 };
static const unsigned char PROGMEM LanderEngine[] =
{ 
B11111111,
B10011001,
B10011001,
B11111111,
B00100100,
B01011010,
B10111101,
B10011001 };
static const unsigned char PROGMEM target[] =
{ 
B11000000, B00000011,
B11100000, B00000111,
B10000000, B00000001,
B11111111, B11111111,
B11000000, B00000011,
};
void setup() {
  // put your setup code here, to run once:
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.cp437(true);
  display.setTextColor(WHITE, BLACK);
  display.clearDisplay();
  Serial.begin(9600);
  pinMode(2,INPUT_PULLUP);
  pinMode(3,INPUT_PULLUP);
  display.invertDisplay(false);
  display.setTextWrap(false);
  //set target
  randomSeed(analogRead(7));//KEEP pin 7 open - it gives noise to make randomseed work
  targetx = random(0,SCREEN_WIDTH-16);
}
void loop() {
  //AFFECT ENGINE FORCES
  //Affect engine thrust sideways
  if(analogRead(XJOY)-512>=XTHRESHOLD&&fuel>0){//left
    playervelocityx-=playeraccelerationx;
    fuel--;
  }
  if(analogRead(XJOY)-512<=-XTHRESHOLD&&fuel>0){//right
    playervelocityx+=playeraccelerationx;
    fuel--;
  }
  //Affect Engine Thrust Upwards
  if(!digitalRead(BUTTON)&&fuel>0){
    playervelocityy+=playerengineacceleration;
    fuel--;
  }
  //Affect environmental forces
  //affect lateral drag
  if(playervelocityx>0){
    playervelocityx-=pow(playervelocityx,2)*dragscalar;
  }
  if(playervelocityx<0){
    playervelocityx+=pow(playervelocityx,2)*dragscalar;
  }
  //affect gravity
  playervelocityy+=playeraccelerationgravity;
  //calculus - integrate the velocity to get position
  playerx+=playervelocityx;
  playery+=playervelocityy;
  //EDGE LIMITS
  if(playerx>SCREEN_WIDTH){
    playerx = 0;
  }
  if(playerx<0){
    playerx = SCREEN_WIDTH;
  }
  if(playery>=SCREEN_HEIGHT){
    playery = SCREEN_HEIGHT;
    playervelocityy = 0;
  }
  //TARGET
  if(playery<=8){//note <=8 because the player is 8 pixils tall
    if(playerx>=targetx&&playerx<=targetx+8&&abs(playervelocityy)<maxlandingvelocityy&&abs(playervelocityx)<maxlandingvelocityx){
      /*everything is calculated using the left corner, so its +8 because when the player's left top corner
      is over 8 pixils away from the target's left top corner, then the player's right leg is on the right flag*/
      display.setCursor(SCREEN_WIDTH/2-25,SCREEN_HEIGHT/2);
      display.print("SUCCESS!");
      display.display();
      delay(2000);
      targetx = random(0,SCREEN_WIDTH-16);
      playery = SCREEN_HEIGHT;
      playerx = SCREEN_WIDTH/2;
      playervelocityy = 0;
      playervelocityx = 0;
      fuel = maxfuel;
    }
    else{
      display.setCursor(SCREEN_WIDTH/2-25,SCREEN_HEIGHT/2);
      display.print("GAME OVER");
      display.display();
      delay(2000);
      targetx = random(0,SCREEN_WIDTH-16);
      playery = SCREEN_HEIGHT;
      playerx = SCREEN_WIDTH/2;
      playervelocityy = 0;
      playervelocityx = 0;
      fuel = maxfuel;
    }
  }
  //draw player
  if(!digitalRead(BUTTON)&&fuel>0){
    display.drawBitmap(playerx,SCREEN_HEIGHT-playery,LanderEngine,8,8,WHITE);
  }
  else{
    display.drawBitmap(playerx,SCREEN_HEIGHT-playery,LanderIdle,8,8,WHITE);
  }
  //draw target
  display.drawBitmap(targetx,SCREEN_HEIGHT-targety,target,16,5,WHITE);
  //draw fuel bar
  display.fillRect(SCREEN_WIDTH-fuelbarwidth, 0, fuelbarwidth, fuelbarmaxheight*fuel/maxfuel, WHITE);
  //draw empty fuel bar background
  display.drawRect(SCREEN_WIDTH-fuelbarwidth, 0, fuelbarwidth, fuelbarmaxheight, WHITE);
  //draw ground
  display.fillRect(0,SCREEN_HEIGHT-1, 128, 1, WHITE);//draws a very big rectangle as the floor
  display.display();
  delay(1);
  display.clearDisplay();
}

#include "arduino_secrets.h"

/*Note - to add cats: add their stats to the respective class, add and reference bitmaps. If they are part of the battlecats, instead of the enemy,
you also have to update them in drawuibitmap and catcostindex to get everything!*/
#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <math.h>
#define SCREEN_WIDTH 128 // OLED display width, in pixels
#define SCREEN_HEIGHT 64 // OLED display height, in pixels
#define OLED_RESET -1 // Reset pin # (or -1 if sharing Arduino reset pin)
#define XJOY A1//the pin numbers of the x joystick and the y joystick
#define YJOY A2
#define BUTTONJOY 3//the joystick button
#define BUTTON 2//the pin number of the button
#define XTHRESHOLD 256//the x threshold to go left and right for joystick
#define YTHRESHOLD 256
//define battlecats stage
#define STAGEBORDER 8//how far from the edge the battlecats stay
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
//BITMAPS
static const unsigned char PROGMEM bitmapbase[] =
{ 
B00000000,
B00000000,
B00000000,
B00000000,
B00000000,
B00000000,
B00000000,
B00000000};
static const unsigned char PROGMEM Catbase[] =
{ 
B11111111,
B00011111,
B11111111,
B00011000,
B00100100,
B01000010,
B11111111,
B10000001,
B10000001,
B10000001,
B10000001,
B10000001,
B10000001,
B10000001,
B10000001,
B11111111};
static const unsigned char PROGMEM Enemybase[] =
{ 
B11111111,
B11111111,
B11111111,
B11111111,
B00100100,
B01000010,
B11111111,
B10000001,
B10000001,
B10000001,
B10000001,
B10000001,
B10000001,
B10000001,
B10000001,
B11111111};
static const unsigned char PROGMEM cat_passive[] =
{ 
B01111110,
B10000001,
B10100101,
B10000001,
B01111110,
B00100100,
B00100100,
B00100100};
static const unsigned char PROGMEM cat_attack[] =
{ 
B01111110,
B10000001,
B10100101,
B10000001,
B01111110,
B00000000,
B00000000,
B00000000};
static const unsigned char PROGMEM wall_cat_passive[] =
{ 
B01111110,
B10000001,
B10100101,
B10000001,
B10111101,
B10000001,
B01111110,
B00100100};
static const unsigned char PROGMEM wall_cat_attack[] =
{ 
B00000000,
B00000000,
B01111110,
B10000001,
B10111101,
B10000001,
B01111110,
B00100100};
static const unsigned char PROGMEM brave_cat_passive[] =
{ 
B00000000,
B00000000,
B00100000,
B00100100,
B00111010,
B00001010,
B00000100,
B00001010};
static const unsigned char PROGMEM brave_cat_attack[] =
{ 
B00000000,
B00000000,
B10000000,
B01000100,
B00111010,
B00001010,
B00000100,
B00001010};
static const unsigned char PROGMEM assassin_bear_passive[] =
{ 
B11110001,
B01100011,
B11110110,
B10011100,
B10011000,
B11110000,
B10010000,
B10010000};
static const unsigned char PROGMEM assassin_bear_attack[] =
{ 
B11110000,
B01100000,
B11110000,
B10011000,
B10011100,
B11110110,
B10010011,
B10010000};
static const unsigned char PROGMEM ufo_cat_passive[] =
{ 
B10000001,
B01111110,
B10000001,
B01111110,
B00101000,
B01000100,
B10000010,
B00000000};
static const unsigned char PROGMEM ufo_cat_attack[] =
{ 
B10000001,
B01111110,
B10000001,
B01111110,
B00011000,
B00110000,
B01100000,
B11000000};
static const unsigned char PROGMEM kangeroo_passive[] =
{ 
B0111000,
B01100000,
B01110000,
B10001101,
B10001010,
B01110000,
B01010000,
B01010000};
static const unsigned char PROGMEM kangeroo_attack[] =
{ 
B0111000,
B01100001,
B01110010,
B10001100,
B10001000,
B01110000,
B01010000,
B01010000};
static const unsigned char PROGMEM bullet_train_cat_passive[] =
{ 
B00000000,
B00000000,
B00000000,
B00011111,
B00101001,
B01001001,
B11111111,
B01010101};
static const unsigned char PROGMEM bullet_train_cat_attack[] =
{ 
B00000000,
B00110000,
B01100000,
B11011111,
B10101001,
B11001001,
B01111111,
B00110101};
static const unsigned char PROGMEM doge_passive[] =
{ 
B00000000,
B11111100,
B10000100,
B10010100,
B10000111,
B10000111,
B11111100,
B01001000};
static const unsigned char PROGMEM doge_attack[] =
{ 
B00000000,
B11111100,
B10000111,
B10010100,
B10000100,
B10000111,
B11111100,
B01001000};
static const unsigned char PROGMEM drill_cat_passive[] =
{ 
B00010000,
B00101100,
B01010010,
B10111001,
B10100001,
B01010010,
B00101100,
B00010000};
static const unsigned char PROGMEM drill_cat_attack[] =
{ 
B01010000,
B10101100,
B01010010,
B10111001,
B10100001,
B01010010,
B10101100,
B01010000};
//UI/MONEY-----------------------------------------------------------------------------------------------------------
const int maxmoney = 200;
const float moneyperframe = 0.12f;
float money = 0;
void drawuibitmap(int catindexnumber,int cost){
  if(catindexnumber == 0){
    display.drawBitmap(0,48,cat_passive,8,8,WHITE);
    display.setCursor(10,48);
    display.print("Cost: ");
    display.print(cost);
    display.print(" Money: ");
    display.print(int(money));
  }
  else if(catindexnumber == 1){
    display.drawBitmap(0,48,wall_cat_passive,8,8,WHITE);
    display.setCursor(10,48);
    display.print("Cost: ");
    display.print(cost);
    display.print(" Money: ");
    display.print(int(money));

  }
  else if(catindexnumber == 2){
    display.drawBitmap(0,48,brave_cat_passive,8,8,WHITE);
    display.setCursor(10,48);
    display.print("Cost: ");
    display.print(cost);
    display.print(" Money: ");
    display.print(int(money));

  }
  else if(catindexnumber == 3){
    display.drawBitmap(0,48,ufo_cat_passive,8,8,WHITE);
    display.setCursor(10,48);
    display.print("Cost: ");
    display.print(cost);
    display.print(" Money: ");
    display.print(int(money));

  }
    else if(catindexnumber == 4){
    display.drawBitmap(0,48,bullet_train_cat_passive,8,8,WHITE);
    display.setCursor(10,48);
    display.print("Cost: ");
    display.print(cost);
    display.print(" Money: ");
    display.print(int(money));

  }
  else if(catindexnumber == 5){
    display.drawBitmap(0,48,drill_cat_passive,8,8,WHITE);
    display.setCursor(10,48);
    display.print("Cost: ");
    display.print(cost);
    display.print(" Money: ");
    display.print(int(money));

  }
}
int catcostindex(int index){//this is a function where if you input the index of the cat, it returns the cost
  switch(index){
    case 0:
      return 10;
    case 1:
      return 20;
    case 2:
      return 50;
    case 3:
      return 50;
    case 4:
      return 30;
    case 5:
      return 50;
  }
}
//CLASSES
class enemy{
  public:
    //these are the cat's stats
    bool alive = 0;
    int hp = 0;
    int damage = 0;
    int damagepoint = 0;
    float xpos = 0;
    float ypos = 0;
    float speed = 0;
    //phases - how many frames the cat is passive and how many frames it attacks for
    int attackphase = 0;
    int passivephase = 0;
    int phasecounter = 0;//this counts how many frames have passed
    bool attacking = 0;//this tells if the player is attacking - takes up memory, but is helpfull for collision physics
    bool hit = 0;
    int standingdist = 0;
    const unsigned char* bitmap;
    const unsigned char* passivebitmap;//this is a pointer that gets assigned to a bitmap in init
    /*basically the way void attackphase is made up is it has a passive phase and an attack phase. In the passive phase, it just waits a certain
    number of frames, and during the attack phase, it goes through its attack animation. The passive phase always runs first, then the attack phase*/
    const unsigned char* attackbitmap;
    bool checkallcollisions();
    void phase(){
      if(phasecounter>attackphase+passivephase){//basically cycles the phase counter around. The passive phase occurs first, then the attack phase
        phasecounter=0;
      }
      if(phasecounter<=passivephase){
        bitmap = passivebitmap;
        attacking = 0;
      }
      else if(phasecounter>=passivephase){
        bitmap = attackbitmap;
        attacking = 1;
      }
      //This only moves the cat when it has space to move
      if(!checkallcollisions()&&xpos<SCREEN_WIDTH-8-STAGEBORDER){//the -8 is to account for the enemy being 8 pixils long
          xpos+= speed;
          phasecounter = 0;
      }
      else{
        phasecounter++;
      }
    }
    void frame(){
      phase();//run the phase check
      display.drawBitmap(xpos,SCREEN_HEIGHT-ypos,bitmap,8,8,WHITE);
      //kill cat
      if(hp <= 0){
        alive = 0;
      }
    }
    void init(int catindexnumber){//this is a bool so that I can use the return function
      phasecounter = 0;//resets to the beginning of the passive phase
      if(catindexnumber == 0){
        passivebitmap = doge_passive;
        attackbitmap = doge_attack;
        hp = 20;
        damage = 5;
        damagepoint = 6;
        xpos = 0;
        ypos = 40;
        speed = 0.5;
        attackphase = 2;
        passivephase = 25;
        standingdist = 2;
      }
      else if(catindexnumber == 1){
        passivebitmap = wall_cat_passive;
        attackbitmap = wall_cat_attack;
        hp = 40;
        damage = 1;
        damagepoint = 6;
        xpos = 0;
        ypos = 40;
        speed = 0.2;
        attackphase = 5;
        passivephase = 25;
        standingdist = 2;
      }
      else if(catindexnumber == 2){
        passivebitmap = assassin_bear_passive;
        attackbitmap = assassin_bear_attack;
        hp = 1;
        damage = 5;
        damagepoint = 5;
        xpos = 0;
        ypos = 40;
        speed = 2.0;
        attackphase = 1;
        passivephase = 1;
        standingdist = 1;
      }
      else if(catindexnumber == 3){
        passivebitmap = kangeroo_passive;
        attackbitmap = kangeroo_attack;
        hp = 5;
        damage = 5;
        damagepoint = 5;
        xpos = 0;
        ypos = 40;
        speed = 1.0;
        attackphase = 1;
        passivephase = 2;
        standingdist = 1;
      }
      alive = 1;
    }
};
class battlecat{
  public:
    //these are the cat's stats
    bool alive = 0;
    int hp = 0;
    int damage = 0;
    int damagepoint = 0;
    float xpos = 0;
    float ypos = 0;
    float speed = 0;
    //phases - how many frames the cat is passive and how many frames it attacks for
    int attackphase = 0;
    int passivephase = 0;
    int phasecounter = 0;//this counts how many frames have passed
    bool attacking = 0;//this tells if the player is attacking - takes up memory, but is helpfull for collision physics
    bool hit = 0;
    int standingdist = 0;
    const unsigned char* bitmap;
    const unsigned char* passivebitmap;//this is a pointer that gets assigned to a bitmap in init
    int catcost = 0;//how much this cat costs
    /*basically the way void attackphase is made up is it has a passive phase and an attack phase. In the passive phase, it just waits a certain
    number of frames, and during the attack phase, it goes through its attack animation. The passive phase always runs first, then the attack phase*/
    const unsigned char* attackbitmap;
    bool checkallcollisions();
    void phase(){
      if(phasecounter>attackphase+passivephase){//basically cycles the phase counter around. The passive phase occurs first, then the attack phase
        phasecounter=0;
      }
      if(phasecounter<=passivephase){
        bitmap = passivebitmap;
        attacking = 0;
      }
      else if(phasecounter>=passivephase){
        bitmap = attackbitmap;
        attacking = 1;
      }
      //This only moves the cat when it has space to move
      if(!checkallcollisions()&&xpos>STAGEBORDER){//the -8 is to account for the enemy being 8 pixils long - THIS ORDER OF CHECKS IS INCREDIBLY IMPORTANT
      //if xpos>stageboarder runs first, checkallcollisions doesnt run at all!
          xpos-= speed;
          if(passivebitmap != drill_cat_passive&&passivebitmap != bullet_train_cat_passive){
            phasecounter = 0;//drill cat and bullet train cat run on different mechanics - they automatically attacks first, then waits passively. No other cat can do this
            //this also gives it a questionable piledrive maneuver where it can piledrive through multiple enemies at once, as long as it 1 taps.
            //It's kinda satisfying to watch, so I'll let it have that ability, however with a massive cooldown
          }
      }
      else{
        phasecounter++;
      }
    }
    void frame(){
      phase();//run the phase check
      display.drawBitmap(xpos,SCREEN_HEIGHT-ypos,bitmap,8,8,WHITE);
      //kill cat
      if(hp <= 0){
        alive = 0;
      }
    }
    bool init(int catindexnumber){
      phasecounter = 0;//resets to the beginning of the passive phase
      if(catindexnumber == 0){
        catcost = catcostindex(catindexnumber);
        if(catcost<=money){
          money-=catcost;
        }
        else{
          return 0;
        }
        passivebitmap = cat_passive;
        attackbitmap = cat_attack;
        hp = 20;
        damage = 5;
        damagepoint = -6;
        xpos = SCREEN_WIDTH-8;
        ypos = 40;
        speed = 0.5;
        attackphase = 2;
        passivephase = 25;
        standingdist = 2;
      }
      else if(catindexnumber == 1){
        catcost = catcostindex(catindexnumber);
        if(catcost<=money){
          money-=catcost;
        }
        else{
          return 0;
        }
        passivebitmap = wall_cat_passive;
        attackbitmap = wall_cat_attack;
        hp = 50;
        damage = 1;
        damagepoint = -6;
        xpos = SCREEN_WIDTH-8;
        ypos = 40;
        speed = 0.2;
        attackphase = 6;
        passivephase = 24;
        standingdist = 2;
      }
      else if(catindexnumber == 2){
        catcost = catcostindex(catindexnumber);
        if(catcost<=money){
          money-=catcost;
        }
        else{
          return 0;
        }
        passivebitmap = brave_cat_passive;
        attackbitmap = brave_cat_attack;
        hp = 10;
        damage = 5;
        damagepoint = -6;
        xpos = SCREEN_WIDTH-8;
        ypos = 40;
        speed = 0.4;
        attackphase = 5;
        passivephase = 15;
        standingdist = 2;
      }
      else if(catindexnumber == 3){
        catcost = catcostindex(catindexnumber);
        if(catcost<=money){
          money-=catcost;
        }
        else{
          return 0;
        }
        passivebitmap = ufo_cat_passive;
        attackbitmap = ufo_cat_attack;
        hp = 20;
        damage = 25;
        damagepoint = -6;
        xpos = SCREEN_WIDTH-8;
        ypos = 48;//as ufo cat floats, its ypos stat is higher
        speed = 0.4;
        attackphase = 2;
        passivephase = 50;
        standingdist = 4;
      }
      if(catindexnumber == 4){
        catcost = catcostindex(catindexnumber);
        if(catcost<=money){
          money-=catcost;
        }
        else{
          return 0;
        }
        passivebitmap = bullet_train_cat_passive;
        attackbitmap = bullet_train_cat_attack;
        hp = 20;
        damage = 10;
        damagepoint = -6;
        xpos = SCREEN_WIDTH-8;
        ypos = 40;
        speed = 2;
        attackphase = 2;
        passivephase = 50;
        standingdist = 4;
        phasecounter = passivephase;//THIS IS ONLY FOR BULLET TRAIN CAT AND DRILL CAT. REMOVE FOR ALL OTHER CATS. IT ENSURES HE ATTACKS INSTANTLY ONCE HE HITS OPPONENT
      }
      else if(catindexnumber == 5){
        catcost = catcostindex(catindexnumber);
        if(catcost<=money){
          money-=catcost;
        }
        else{
          return 0;
        }
        passivebitmap = drill_cat_passive;
        attackbitmap = drill_cat_attack;
        hp = 20;
        damage = 10;
        damagepoint = -6;//long range attacks
        xpos = SCREEN_WIDTH-8;
        ypos = 40;
        speed = 1.5;
        attackphase = 5;
        passivephase = 500;//drill cat has the piledrive ability, allowing it to fly through multiple enemies. However it has a major cooldown after
        standingdist = 4;
        phasecounter = passivephase;//THIS IS ONLY FOR BULLET TRAIN CAT AND DRILL CAT. REMOVE FOR ALL OTHER CATS. IT ENSURES HE ATTACKS INSTANTLY ONCE HE HITS OPPONENT
      }
      alive = 1;
      return 1;
    }
};

//define the list of battlecats and enemies--------------------------------------
const int maxcats = 4;//the maximum cats allowed on the field at once
const int maxenemies = 3;
battlecat catlist[maxcats];
enemy enemylist[maxenemies];

bool battlecat::checkallcollisions(){
  for(enemy &currentenemy:enemylist){
    if(currentenemy.attacking&&currentenemy.damagepoint+currentenemy.xpos+8>this->xpos&&currentenemy.damagepoint+currentenemy.xpos+8<this->xpos+8&&currentenemy.alive){
      this->hp-=currentenemy.damage;
    }
    if(currentenemy.xpos<this->xpos-standingdist&&currentenemy.xpos+8>this->xpos-standingdist&&currentenemy.alive){
      return 1;
    }
  }
  return 0;//if absolutely no collisions are detected
}
bool enemy::checkallcollisions(){
  for(battlecat &currentcat:catlist){
    if(currentcat.attacking&&currentcat.damagepoint+currentcat.xpos>this->xpos&&currentcat.damagepoint+currentcat.xpos<this->xpos+8&&currentcat.alive){
      this->hp-=currentcat.damage;
    }
    if(currentcat.xpos<this->xpos+8+this->standingdist&&currentcat.xpos+8>this->xpos+8+this->standingdist&&currentcat.alive){
      return 1;
    }
  }
  return 0;//if absolutely no collisions are detected
}
//VARIABLE DEFINITIONS
const int hotbarlength = 8;
int hotbar[hotbarlength] = {0,1,2,3,4,5,6,7};
int currenthotbarslot = 0;
//button click mechanism - it makes it so the button has to be clicked and released
bool buttonclick = 0;
bool joymove = 0;//same as buttonclick but for the joystick
//BASE HEALTH-------------------------------------------------------------------------------------------------------
int catbasehealth = 200;
int enemybasehealth = 200;
//enemy randomness mechanism
int randomenemy = 0;
void setup() {
  // put your setup code here, to run once:
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.cp437(true);
  display.setTextColor(WHITE, BLACK);
  display.clearDisplay();
  Serial.begin(9600);
  pinMode(2,INPUT_PULLUP);
  pinMode(3,INPUT_PULLUP);
  display.invertDisplay(false);
  display.setTextWrap(false);
  randomSeed(analogRead(A7));
}
void loop() {
  //main loop
  //MONEY
  if(money<maxmoney){
    money+=moneyperframe;
  }
  //reset button and joy click
  if(digitalRead(BUTTON)){
    buttonclick = 0;
  }
  if(abs(analogRead(XJOY)-512)<XTHRESHOLD){
    joymove = 0;
  }
  if(analogRead(XJOY)-512>XTHRESHOLD&&currenthotbarslot<hotbarlength&&joymove==0){
    currenthotbarslot++;
    joymove = 1;
  }
  if(analogRead(XJOY)-512<-XTHRESHOLD&&currenthotbarslot>0&&joymove==0){
    currenthotbarslot--;
    joymove = 1;
  }
  //use the UI, move the joystick
  if(!digitalRead(BUTTON)&&buttonclick == 0){
    buttonclick = 1;//it only registers a button press if the button has been released and then pressed
    for(battlecat &catpointer:catlist){
      if(catpointer.alive == 0){
        catpointer.init(hotbar[currenthotbarslot]);
        break;
      }
    }
  }
  for(battlecat &catpointer:catlist){
    if(catpointer.alive){
      catpointer.frame();
    }
  }
  for(enemy &enemypointer:enemylist){
    if(enemypointer.alive){
      enemypointer.frame();
    }
  }
  //summon random enemies------------------------------------------------------------------------------------
  randomenemy = random(0,5000);
  for(enemy &enemypointer:enemylist){
    if(enemypointer.alive == 0){
      if(randomenemy >= 0&&randomenemy<=50){
        enemypointer.init(0);
      }
      else if(randomenemy >= 50&&randomenemy<=75){
        enemypointer.init(1);
      }
      else if(randomenemy >= 75&&randomenemy<=80&&millis()>=30000){//the millis thing basically makes it so if the player is within 30 seconds of starting the game, they dont get 1 tapped T_T
        enemypointer.init(2);
      }
      else if(randomenemy >= 80&&randomenemy<=85&&millis()>=30000){
        enemypointer.init(3);
      }
      break;
    }
  }
  //CAT AND ENEMY BASE HEALTH MODIFIERS
  //cat
  for(enemy &currentenemy:enemylist){
    if(currentenemy.attacking&&currentenemy.damagepoint+currentenemy.xpos+8>SCREEN_WIDTH-8&&currentenemy.damagepoint+currentenemy.xpos+8<SCREEN_WIDTH&&currentenemy.alive){
      catbasehealth-=currentenemy.damage;
    }
  }
  if(catbasehealth<=0){
    display.clearDisplay();
    display.setCursor(SCREEN_WIDTH/2-25,SCREEN_HEIGHT/2);
    display.print("GAME OVER");
    display.display();
    delay(100000);
  }
  //enemy
  for(battlecat &currentcat:catlist){
    if(currentcat.attacking&&currentcat.damagepoint+currentcat.xpos>0&&currentcat.damagepoint+currentcat.xpos<0+8&&currentcat.alive){
      enemybasehealth-=currentcat.damage;
    }
  }
  if(enemybasehealth<=0){
    display.clearDisplay();
    display.setCursor(SCREEN_WIDTH/2-25,SCREEN_HEIGHT/2);
    display.print("SUCCESS!");
    display.display();
    delay(100000);
  }
  //draw cat and enemy bases
  display.drawBitmap(SCREEN_WIDTH-8,16,Catbase,8,16,WHITE);
  display.drawBitmap(0,16,Enemybase,8,16,WHITE);
  //draw cat and enemy base healths
  //draw enemy base health
  display.setCursor(0,0);
  display.print(enemybasehealth);
  display.setCursor(SCREEN_WIDTH-18,0);
  display.print(catbasehealth);
  //draw floor
  display.drawLine(0, 32, SCREEN_WIDTH, 32, WHITE);
  //draw current cat
  drawuibitmap(hotbar[currenthotbarslot],catcostindex(hotbar[currenthotbarslot]));//THIS DRAWS THE MONEY AS WELL AS THE CAT IMAGE AND THE COST!!!
  display.display();
  delay(1);
  display.clearDisplay();
}
